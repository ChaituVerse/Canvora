// pptx-generator.js

document.addEventListener("DOMContentLoaded", () => {
    const generateBtn = document.querySelector("#generate-pptx-btn");
    const promptInput = document.querySelector("#pptx-prompt");
    const downloadLink = document.querySelector("#pptx-download");
    const creditsNeeded = 10;

    generateBtn.addEventListener("click", async () => {
        const prompt = promptInput.value.trim();
        if(!prompt) { alert("Enter prompt"); return; }

        // Deduct CV credits
        if(!useCredits(creditsNeeded)) return;

        // Disable button & show generating
        generateBtn.disabled = true;
        generateBtn.textContent = "Generating...";

        try {
            // Call your API here (example placeholder)
            const res = await fetch("/api/generate-pptx", {
                method:"POST",
                headers: {"Content-Type":"application/json"},
                body: JSON.stringify({prompt})
            });
            const data = await res.json();

            // Show download link
            downloadLink.href = data.fileUrl;
            downloadLink.style.display = "inline-block";
            downloadLink.textContent = "Download PPTX";

        } catch(err){
            alert("Error generating PPTX");
            console.error(err);
        } finally {
            generateBtn.disabled = false;
            generateBtn.textContent = "Generate PPTX";
        }
    });
});

// image-generator.js

document.addEventListener("DOMContentLoaded", () => {
    const generateBtn = document.querySelector("#generate-image-btn");
    const promptInput = document.querySelector("#image-prompt");
    const previewArea = document.querySelector("#image-preview");
    const creditsNeeded = 5;

    generateBtn.addEventListener("click", async () => {
        const prompt = promptInput.value.trim();
        if(!prompt) { alert("Enter prompt"); return; }

        // Deduct CV credits
        if(!useCredits(creditsNeeded)) return;

        // Show loading
        previewArea.innerHTML = "<p style='color:#a78bfa;'>Generating image...</p>";

        try {
            // Call your API here (example placeholder)
            const res = await fetch("/api/generate-image", {
                method:"POST",
                headers: {"Content-Type":"application/json"},
                body: JSON.stringify({prompt})
            });
            const data = await res.json();

            // Display image
            previewArea.innerHTML = `<img src="${data.imageUrl}" alt="Generated Image" />`;

        } catch(err){
            previewArea.innerHTML = "<p style='color:red;'>Error generating image</p>";
            console.error(err);
        }
    });
});

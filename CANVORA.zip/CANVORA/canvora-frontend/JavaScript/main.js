// main.js

document.addEventListener("DOMContentLoaded", () => {
    console.log("Main.js loaded");

    // Sidebar link highlight
    const links = document.querySelectorAll(".nav-link");
    links.forEach(link => {
        link.addEventListener("click", () => {
            links.forEach(l => l.classList.remove("active"));
            link.classList.add("active");
        });
    });

    // CV Credits display
    const credits = document.querySelector("#cv-credits");
    if(credits) credits.textContent = localStorage.getItem("cvCredits") || "100"; // default 100 credits
});

// cvcredits.js

function getCredits() {
    return parseInt(localStorage.getItem("cvCredits") || "100");
}

function setCredits(value) {
    localStorage.setItem("cvCredits", value);
    updateCreditsUI();
}

function updateCreditsUI() {
    const creditsDisplay = document.querySelector(".credits-value");
    if (creditsDisplay) {
        creditsDisplay.textContent = getCredits();
    }
}

// Deduct credits per tool usage
function useCredits(amount) {
    let current = getCredits();
    if(current >= amount){
        setCredits(current - amount);
        return true;
    } else {
        alert("Not enough CV Credits! Please purchase more.");
        return false;
    }
}

// Add credits (simulate purchase)
function addCredits(amount) {
    let current = getCredits();
    setCredits(current + amount);
}

// Initialize UI
document.addEventListener("DOMContentLoaded", updateCreditsUI);

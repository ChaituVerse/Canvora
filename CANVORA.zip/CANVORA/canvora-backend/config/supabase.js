import { createClient } from "@supabase/supabase-js";

let supabase;

const connectSupabase = () => {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
    console.error("❌ Missing Supabase credentials in .env");
    return;
  }
  supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
  console.log("✅ Supabase connected successfully");
};

export { supabase };
export default connectSupabase;